# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.0.0 for Mac OS X ARM (64-bit) (December 13, 2023)
# Date: Thu 2 May 2024 21:00:33


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



