# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.0.0 for Mac OS X ARM (64-bit) (December 13, 2023)
# Date: Thu 2 May 2024 21:00:33


from object_library import all_vertices, Vertex
import particles as P
import couplings as C
import lorentz as L


V_1 = Vertex(name = 'V_1',
             particles = [ P.g, P.g, P.g ],
             color = [ 'f(1,2,3)' ],
             lorentz = [ L.VVV3, L.VVV4 ],
             couplings = {(0,1):C.GC_1,(0,0):C.GC_8})

V_2 = Vertex(name = 'V_2',
             particles = [ P.u__tilde__, P.u, P.g ],
             color = [ 'T(3,2,1)' ],
             lorentz = [ L.FFV5, L.FFV6 ],
             couplings = {(0,0):C.GC_9,(0,1):C.GC_11})

V_3 = Vertex(name = 'V_3',
             particles = [ P.c__tilde__, P.c, P.g ],
             color = [ 'T(3,2,1)' ],
             lorentz = [ L.FFV5, L.FFV6 ],
             couplings = {(0,0):C.GC_9,(0,1):C.GC_11})

V_4 = Vertex(name = 'V_4',
             particles = [ P.t__tilde__, P.t, P.g ],
             color = [ 'T(3,2,1)' ],
             lorentz = [ L.FFV5, L.FFV6 ],
             couplings = {(0,0):C.GC_9,(0,1):C.GC_11})

V_5 = Vertex(name = 'V_5',
             particles = [ P.d__tilde__, P.u, P.W__minus__ ],
             color = [ 'Identity(1,2)' ],
             lorentz = [ L.FFV4 ],
             couplings = {(0,0):C.GC_10})

V_6 = Vertex(name = 'V_6',
             particles = [ P.s__tilde__, P.c, P.W__minus__ ],
             color = [ 'Identity(1,2)' ],
             lorentz = [ L.FFV4 ],
             couplings = {(0,0):C.GC_10})

V_7 = Vertex(name = 'V_7',
             particles = [ P.b__tilde__, P.t, P.W__minus__ ],
             color = [ 'Identity(1,2)' ],
             lorentz = [ L.FFV4 ],
             couplings = {(0,0):C.GC_10})

V_8 = Vertex(name = 'V_8',
             particles = [ P.u__tilde__, P.d, P.W__plus__ ],
             color = [ 'Identity(1,2)' ],
             lorentz = [ L.FFV4 ],
             couplings = {(0,0):C.GC_10})

V_9 = Vertex(name = 'V_9',
             particles = [ P.c__tilde__, P.s, P.W__plus__ ],
             color = [ 'Identity(1,2)' ],
             lorentz = [ L.FFV4 ],
             couplings = {(0,0):C.GC_10})

V_10 = Vertex(name = 'V_10',
              particles = [ P.t__tilde__, P.b, P.W__plus__ ],
              color = [ 'Identity(1,2)' ],
              lorentz = [ L.FFV4 ],
              couplings = {(0,0):C.GC_10})

V_11 = Vertex(name = 'V_11',
              particles = [ P.e__plus__, P.ve, P.W__minus__ ],
              color = [ '1' ],
              lorentz = [ L.FFV4 ],
              couplings = {(0,0):C.GC_10})

V_12 = Vertex(name = 'V_12',
              particles = [ P.mu__plus__, P.vm, P.W__minus__ ],
              color = [ '1' ],
              lorentz = [ L.FFV4 ],
              couplings = {(0,0):C.GC_10})

V_13 = Vertex(name = 'V_13',
              particles = [ P.ta__plus__, P.vt, P.W__minus__ ],
              color = [ '1' ],
              lorentz = [ L.FFV4 ],
              couplings = {(0,0):C.GC_10})

V_14 = Vertex(name = 'V_14',
              particles = [ P.ve__tilde__, P.e__minus__, P.W__plus__ ],
              color = [ '1' ],
              lorentz = [ L.FFV4 ],
              couplings = {(0,0):C.GC_10})

V_15 = Vertex(name = 'V_15',
              particles = [ P.vm__tilde__, P.mu__minus__, P.W__plus__ ],
              color = [ '1' ],
              lorentz = [ L.FFV4 ],
              couplings = {(0,0):C.GC_10})

V_16 = Vertex(name = 'V_16',
              particles = [ P.vt__tilde__, P.ta__minus__, P.W__plus__ ],
              color = [ '1' ],
              lorentz = [ L.FFV4 ],
              couplings = {(0,0):C.GC_10})

V_17 = Vertex(name = 'V_17',
              particles = [ P.u__tilde__, P.u, P.g, P.g ],
              color = [ 'd(-1,3,4)*T(-1,2,1)', 'f(-1,3,4)*T(-1,2,1)', 'Identity(1,2)*Identity(3,4)' ],
              lorentz = [ L.FFVV10, L.FFVV11, L.FFVV7, L.FFVV8, L.FFVV9 ],
              couplings = {(2,3):C.GC_2,(0,3):C.GC_4,(1,2):C.GC_3,(2,1):C.GC_5,(0,1):C.GC_7,(1,0):C.GC_6,(1,4):C.GC_12})

V_18 = Vertex(name = 'V_18',
              particles = [ P.c__tilde__, P.c, P.g, P.g ],
              color = [ 'd(-1,3,4)*T(-1,2,1)', 'f(-1,3,4)*T(-1,2,1)', 'Identity(1,2)*Identity(3,4)' ],
              lorentz = [ L.FFVV10, L.FFVV11, L.FFVV7, L.FFVV8, L.FFVV9 ],
              couplings = {(2,3):C.GC_2,(0,3):C.GC_4,(1,2):C.GC_3,(2,1):C.GC_5,(0,1):C.GC_7,(1,0):C.GC_6,(1,4):C.GC_12})

V_19 = Vertex(name = 'V_19',
              particles = [ P.t__tilde__, P.t, P.g, P.g ],
              color = [ 'd(-1,3,4)*T(-1,2,1)', 'f(-1,3,4)*T(-1,2,1)', 'Identity(1,2)*Identity(3,4)' ],
              lorentz = [ L.FFVV10, L.FFVV11, L.FFVV7, L.FFVV8, L.FFVV9 ],
              couplings = {(2,3):C.GC_2,(0,3):C.GC_4,(1,2):C.GC_3,(2,1):C.GC_5,(0,1):C.GC_7,(1,0):C.GC_6,(1,4):C.GC_12})

