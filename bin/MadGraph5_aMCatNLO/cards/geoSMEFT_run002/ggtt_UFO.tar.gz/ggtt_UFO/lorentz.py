# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.0.0 for Mac OS X ARM (64-bit) (December 13, 2023)
# Date: Thu 2 May 2024 21:00:33


from object_library import all_lorentz, Lorentz

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot
try:
   import form_factors as ForFac 
except ImportError:
   pass


FFV4 = Lorentz(name = 'FFV4',
               spins = [ 2, 2, 3 ],
               structure = 'Gamma(3,2,-1)*ProjM(-1,1)')

FFV5 = Lorentz(name = 'FFV5',
               spins = [ 2, 2, 3 ],
               structure = 'Gamma(3,2,-1)*ProjM(-1,1) + Gamma(3,2,-1)*ProjP(-1,1)')

FFV6 = Lorentz(name = 'FFV6',
               spins = [ 2, 2, 3 ],
               structure = '-(P(-1,3)*Gamma(-1,2,-3)*Gamma(3,-3,-2)*ProjM(-2,1)) + P(-1,3)*Gamma(-1,-3,-2)*Gamma(3,2,-3)*ProjM(-2,1) - P(-1,3)*Gamma(-1,2,-3)*Gamma(3,-3,-2)*ProjP(-2,1) + P(-1,3)*Gamma(-1,-3,-2)*Gamma(3,2,-3)*ProjP(-2,1)')

VVV3 = Lorentz(name = 'VVV3',
               spins = [ 3, 3, 3 ],
               structure = 'P(3,1)*Metric(1,2) - P(3,2)*Metric(1,2) - P(2,1)*Metric(1,3) + P(2,3)*Metric(1,3) + P(1,2)*Metric(2,3) - P(1,3)*Metric(2,3)')

VVV4 = Lorentz(name = 'VVV4',
               spins = [ 3, 3, 3 ],
               structure = '-(P(1,2)*P(2,3)*P(3,1)) + P(1,3)*P(2,1)*P(3,2) + P(-1,2)*P(-1,3)*P(3,1)*Metric(1,2) - P(-1,1)*P(-1,3)*P(3,2)*Metric(1,2) - P(-1,2)*P(-1,3)*P(2,1)*Metric(1,3) + P(-1,1)*P(-1,2)*P(2,3)*Metric(1,3) + P(-1,1)*P(-1,3)*P(1,2)*Metric(2,3) - P(-1,1)*P(-1,2)*P(1,3)*Metric(2,3)')

FFVV7 = Lorentz(name = 'FFVV7',
                spins = [ 2, 2, 3, 3 ],
                structure = '-(P(-2,1)*P(-2,4)*P(-1,3)*Gamma(-1,2,-3)*Metric(3,4)*ProjM(-3,1)) + P(-2,2)*P(-2,4)*P(-1,3)*Gamma(-1,2,-3)*Metric(3,4)*ProjM(-3,1) + P(-2,1)*P(-2,3)*P(-1,4)*Gamma(-1,2,-3)*Metric(3,4)*ProjM(-3,1) - P(-2,2)*P(-2,3)*P(-1,4)*Gamma(-1,2,-3)*Metric(3,4)*ProjM(-3,1) + P(-1,3)*P(3,4)*P(4,1)*Gamma(-1,2,-2)*ProjM(-2,1) - P(-1,3)*P(3,4)*P(4,2)*Gamma(-1,2,-2)*ProjM(-2,1) - P(-1,4)*P(3,1)*P(4,3)*Gamma(-1,2,-2)*ProjM(-2,1) + P(-1,4)*P(3,2)*P(4,3)*Gamma(-1,2,-2)*ProjM(-2,1) - P(-1,3)*P(-1,4)*P(4,1)*Gamma(3,2,-2)*ProjM(-2,1) + P(-1,3)*P(-1,4)*P(4,2)*Gamma(3,2,-2)*ProjM(-2,1) + P(-1,1)*P(-1,4)*P(4,3)*Gamma(3,2,-2)*ProjM(-2,1) - P(-1,2)*P(-1,4)*P(4,3)*Gamma(3,2,-2)*ProjM(-2,1) + P(-1,3)*P(-1,4)*P(3,1)*Gamma(4,2,-2)*ProjM(-2,1) - P(-1,3)*P(-1,4)*P(3,2)*Gamma(4,2,-2)*ProjM(-2,1) - P(-1,1)*P(-1,3)*P(3,4)*Gamma(4,2,-2)*ProjM(-2,1) + P(-1,2)*P(-1,3)*P(3,4)*Gamma(4,2,-2)*ProjM(-2,1)')

FFVV8 = Lorentz(name = 'FFVV8',
                spins = [ 2, 2, 3, 3 ],
                structure = '-(P(-2,1)*P(-2,4)*P(-1,3)*Gamma(-1,2,-3)*Metric(3,4)*ProjM(-3,1)) + P(-2,2)*P(-2,4)*P(-1,3)*Gamma(-1,2,-3)*Metric(3,4)*ProjM(-3,1) - P(-2,1)*P(-2,3)*P(-1,4)*Gamma(-1,2,-3)*Metric(3,4)*ProjM(-3,1) + P(-2,2)*P(-2,3)*P(-1,4)*Gamma(-1,2,-3)*Metric(3,4)*ProjM(-3,1) + P(-1,3)*P(3,4)*P(4,1)*Gamma(-1,2,-2)*ProjM(-2,1) - P(-1,3)*P(3,4)*P(4,2)*Gamma(-1,2,-2)*ProjM(-2,1) + P(-1,4)*P(3,1)*P(4,3)*Gamma(-1,2,-2)*ProjM(-2,1) - P(-1,4)*P(3,2)*P(4,3)*Gamma(-1,2,-2)*ProjM(-2,1) - P(-1,3)*P(-1,4)*P(4,1)*Gamma(3,2,-2)*ProjM(-2,1) + P(-1,3)*P(-1,4)*P(4,2)*Gamma(3,2,-2)*ProjM(-2,1) + P(-1,1)*P(-1,4)*P(4,3)*Gamma(3,2,-2)*ProjM(-2,1) - P(-1,2)*P(-1,4)*P(4,3)*Gamma(3,2,-2)*ProjM(-2,1) - P(-1,3)*P(-1,4)*P(3,1)*Gamma(4,2,-2)*ProjM(-2,1) + P(-1,3)*P(-1,4)*P(3,2)*Gamma(4,2,-2)*ProjM(-2,1) + P(-1,1)*P(-1,3)*P(3,4)*Gamma(4,2,-2)*ProjM(-2,1) - P(-1,2)*P(-1,3)*P(3,4)*Gamma(4,2,-2)*ProjM(-2,1)')

FFVV9 = Lorentz(name = 'FFVV9',
                spins = [ 2, 2, 3, 3 ],
                structure = 'Gamma(3,2,-2)*Gamma(4,-2,-1)*ProjM(-1,1) - Gamma(3,-2,-1)*Gamma(4,2,-2)*ProjM(-1,1) + Gamma(3,2,-2)*Gamma(4,-2,-1)*ProjP(-1,1) - Gamma(3,-2,-1)*Gamma(4,2,-2)*ProjP(-1,1)')

FFVV10 = Lorentz(name = 'FFVV10',
                 spins = [ 2, 2, 3, 3 ],
                 structure = '-(P(-2,1)*P(-2,4)*P(-1,3)*Gamma(-1,2,-3)*Metric(3,4)*ProjP(-3,1)) + P(-2,2)*P(-2,4)*P(-1,3)*Gamma(-1,2,-3)*Metric(3,4)*ProjP(-3,1) + P(-2,1)*P(-2,3)*P(-1,4)*Gamma(-1,2,-3)*Metric(3,4)*ProjP(-3,1) - P(-2,2)*P(-2,3)*P(-1,4)*Gamma(-1,2,-3)*Metric(3,4)*ProjP(-3,1) + P(-1,3)*P(3,4)*P(4,1)*Gamma(-1,2,-2)*ProjP(-2,1) - P(-1,3)*P(3,4)*P(4,2)*Gamma(-1,2,-2)*ProjP(-2,1) - P(-1,4)*P(3,1)*P(4,3)*Gamma(-1,2,-2)*ProjP(-2,1) + P(-1,4)*P(3,2)*P(4,3)*Gamma(-1,2,-2)*ProjP(-2,1) - P(-1,3)*P(-1,4)*P(4,1)*Gamma(3,2,-2)*ProjP(-2,1) + P(-1,3)*P(-1,4)*P(4,2)*Gamma(3,2,-2)*ProjP(-2,1) + P(-1,1)*P(-1,4)*P(4,3)*Gamma(3,2,-2)*ProjP(-2,1) - P(-1,2)*P(-1,4)*P(4,3)*Gamma(3,2,-2)*ProjP(-2,1) + P(-1,3)*P(-1,4)*P(3,1)*Gamma(4,2,-2)*ProjP(-2,1) - P(-1,3)*P(-1,4)*P(3,2)*Gamma(4,2,-2)*ProjP(-2,1) - P(-1,1)*P(-1,3)*P(3,4)*Gamma(4,2,-2)*ProjP(-2,1) + P(-1,2)*P(-1,3)*P(3,4)*Gamma(4,2,-2)*ProjP(-2,1)')

FFVV11 = Lorentz(name = 'FFVV11',
                 spins = [ 2, 2, 3, 3 ],
                 structure = '-(P(-2,1)*P(-2,4)*P(-1,3)*Gamma(-1,2,-3)*Metric(3,4)*ProjP(-3,1)) + P(-2,2)*P(-2,4)*P(-1,3)*Gamma(-1,2,-3)*Metric(3,4)*ProjP(-3,1) - P(-2,1)*P(-2,3)*P(-1,4)*Gamma(-1,2,-3)*Metric(3,4)*ProjP(-3,1) + P(-2,2)*P(-2,3)*P(-1,4)*Gamma(-1,2,-3)*Metric(3,4)*ProjP(-3,1) + P(-1,3)*P(3,4)*P(4,1)*Gamma(-1,2,-2)*ProjP(-2,1) - P(-1,3)*P(3,4)*P(4,2)*Gamma(-1,2,-2)*ProjP(-2,1) + P(-1,4)*P(3,1)*P(4,3)*Gamma(-1,2,-2)*ProjP(-2,1) - P(-1,4)*P(3,2)*P(4,3)*Gamma(-1,2,-2)*ProjP(-2,1) - P(-1,3)*P(-1,4)*P(4,1)*Gamma(3,2,-2)*ProjP(-2,1) + P(-1,3)*P(-1,4)*P(4,2)*Gamma(3,2,-2)*ProjP(-2,1) + P(-1,1)*P(-1,4)*P(4,3)*Gamma(3,2,-2)*ProjP(-2,1) - P(-1,2)*P(-1,4)*P(4,3)*Gamma(3,2,-2)*ProjP(-2,1) - P(-1,3)*P(-1,4)*P(3,1)*Gamma(4,2,-2)*ProjP(-2,1) + P(-1,3)*P(-1,4)*P(3,2)*Gamma(4,2,-2)*ProjP(-2,1) + P(-1,1)*P(-1,3)*P(3,4)*Gamma(4,2,-2)*ProjP(-2,1) - P(-1,2)*P(-1,3)*P(3,4)*Gamma(4,2,-2)*ProjP(-2,1)')

